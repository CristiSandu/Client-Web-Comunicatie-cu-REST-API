#ifndef _REQUESTS_
#define _REQUESTS_

#include "json.hpp"
#include <string>
#include <iostream>
#include <bits/stdc++.h>
using namespace std; 
// computes and returns a GET request string (query_params
// and cookies can be set to NULL if not needed)
char *compute_get_request(char *host,char *url, string get_books,
							string cookies, string JWT, string id_carte);

// computes and returns a POST request string (cookies can be NULL if not needed)
char *compute_post_request(char *host, char *url, char* content_type, nlohmann::json arr ,
							 int ok , string JWT);

#endif
